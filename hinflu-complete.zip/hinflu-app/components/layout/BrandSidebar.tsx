'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { href:'/brand/dashboard', label:'Dashboard', icon:'▦' },
  { href:'/brand/campaigns', label:'Campaigns', icon:'◈', badge:'3' },
  { href:'/brand/messages', label:'Messages', icon:'◻', badge:'5' },
  { href:'/brand/shortlisted', label:'Shortlisted', icon:'★', badge:'8' },
  { href:'/brand/contracts', label:'Contracts', icon:'◇' },
  { href:'/brand/payments', label:'Payments', icon:'◈' },
  { href:'/discover', label:'Discover Creators', icon:'◉' },
  { href:'/brand/settings', label:'Settings', icon:'⚙' },
]

export default function BrandSidebar() {
  const pathname = usePathname()
  return (
    <aside style={{width:210,background:'#fafafa',borderRight:'0.5px solid #e5e5e5',display:'flex',flexDirection:'column',minHeight:'100vh',position:'fixed',top:0,left:0,zIndex:50}}>
      <div style={{padding:'1.25rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <Link href="/" style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,fontWeight:600,letterSpacing:2,color:'#1a1a1a',textDecoration:'none'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</Link>
        <div style={{fontSize:10,color:'#999',letterSpacing:0.5,marginTop:2}}>Brand Portal</div>
      </div>
      <nav style={{flex:1,padding:'0.75rem 0'}}>
        <div style={{fontSize:10,letterSpacing:1.5,textTransform:'uppercase',color:'#bbb',padding:'0 1.25rem',margin:'0.75rem 0 0.3rem'}}>Main</div>
        {navItems.map(item => {
          const active = pathname === item.href || pathname.startsWith(item.href+'/') 
          return (
            <Link key={item.href} href={item.href} style={{display:'flex',alignItems:'center',gap:9,padding:'8px 1.25rem',fontSize:12,color:active?'#1a1a1a':'#666',textDecoration:'none',borderLeft:active?'2px solid #B8860B':'2px solid transparent',background:active?'#fff':'transparent',fontWeight:active?500:400}}>
              <span style={{fontSize:14}}>{item.icon}</span>
              <span style={{flex:1}}>{item.label}</span>
              {item.badge && <span style={{fontSize:10,background:'#fdf8ee',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:8,padding:'1px 6px'}}>{item.badge}</span>}
            </Link>
          )
        })}
      </nav>
      <div style={{padding:'1rem 1.25rem',borderTop:'0.5px solid #e5e5e5'}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:32,height:32,borderRadius:'50%',background:'#fdf3de',border:'0.5px solid #d4a843',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:500,color:'#8B5E0A'}}>NB</div>
          <div>
            <div style={{fontSize:12,fontWeight:500}}>Nova Brand</div>
            <div style={{fontSize:10,color:'#B8860B'}}>Pro Plan</div>
          </div>
        </div>
        <button onClick={()=>{fetch('/api/auth/logout',{method:'POST'}).then(()=>window.location.href='/login')}} style={{marginTop:'0.75rem',width:'100%',padding:'7px',fontSize:11,color:'#999',background:'transparent',border:'0.5px solid #e5e5e5',borderRadius:2,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Sign out</button>
      </div>
    </aside>
  )
}
