'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { href:'/creator/dashboard', label:'Dashboard', icon:'▦' },
  { href:'/creator/offers', label:'Brand Offers', icon:'◈', badge:'3' },
  { href:'/creator/campaigns', label:'Browse Campaigns', icon:'◉' },
  { href:'/creator/messages', label:'Messages', icon:'◻', badge:'2' },
  { href:'/creator/contracts', label:'Contracts', icon:'◇' },
  { href:'/creator/earnings', label:'Earnings', icon:'$' },
  { href:'/creator/settings', label:'Settings', icon:'⚙' },
]

export default function CreatorSidebar() {
  const pathname = usePathname()
  return (
    <aside style={{width:210,background:'#fafafa',borderRight:'0.5px solid #e5e5e5',display:'flex',flexDirection:'column',minHeight:'100vh',position:'fixed',top:0,left:0,zIndex:50}}>
      <div style={{padding:'1.25rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <Link href="/" style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,fontWeight:600,letterSpacing:2,color:'#1a1a1a',textDecoration:'none'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</Link>
        <div style={{fontSize:10,color:'#999',letterSpacing:0.5,marginTop:2}}>Creator Portal</div>
      </div>
      <nav style={{flex:1,padding:'0.75rem 0'}}>
        {navItems.map(item => {
          const active = pathname === item.href
          return (
            <Link key={item.href} href={item.href} style={{display:'flex',alignItems:'center',gap:9,padding:'8px 1.25rem',fontSize:12,color:active?'#1a1a1a':'#666',textDecoration:'none',borderLeft:active?'2px solid #B8860B':'2px solid transparent',background:active?'#fff':'transparent',fontWeight:active?500:400}}>
              <span style={{fontSize:14}}>{item.icon}</span>
              <span style={{flex:1}}>{item.label}</span>
              {item.badge && <span style={{fontSize:10,background:'#fdf8ee',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:8,padding:'1px 6px'}}>{item.badge}</span>}
            </Link>
          )
        })}
      </nav>
      <div style={{padding:'1rem 1.25rem',borderTop:'0.5px solid #e5e5e5'}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:32,height:32,borderRadius:'50%',background:'#fdf3de',border:'0.5px solid #d4a843',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:500,color:'#8B5E0A',fontFamily:"'Cormorant Garamond',serif"}}>SA</div>
          <div>
            <div style={{fontSize:12,fontWeight:500}}>Sofia Amir</div>
            <div style={{fontSize:10,color:'#B8860B'}}>Mega Influencer</div>
          </div>
        </div>
        <button onClick={()=>window.location.href='/login'} style={{marginTop:'0.75rem',width:'100%',padding:'7px',fontSize:11,color:'#999',background:'transparent',border:'0.5px solid #e5e5e5',borderRadius:2,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Sign out</button>
      </div>
    </aside>
  )
}
