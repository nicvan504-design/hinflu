'use client'
import { useState } from 'react'
import Link from 'next/link'

const PLANS = [
  { name:'Starter', monthly:99, annual:79, desc:'Perfect for small brands running first influencer campaigns.', cta:'Get started free', ctaStyle:'outline',
    features:['Up to 3 active campaigns','Access to 5,000 creators','Basic analytics dashboard','In-app messaging'],
    missing:['AI creator matching','Contract management','Dedicated account manager'] },
  { name:'Pro', monthly:299, annual:239, desc:'For growing brands wanting smarter targeting and deeper analytics.', cta:'Start Pro trial', ctaStyle:'gold', popular:true,
    features:['Unlimited campaigns','Full creator network (48K+)','AI creator matching','Advanced analytics + export','Contract management','Escrow payments'],
    missing:['Dedicated account manager'] },
  { name:'Enterprise', monthly:null, annual:null, desc:'For large brands and agencies running high-volume programs.', cta:'Contact sales', ctaStyle:'dark',
    features:['Everything in Pro','Dedicated account manager','White-label reporting','Custom API access','SLA + priority support','Multi-user team access'],
    missing:[] },
]

export default function PricingPage() {
  const [annual, setAnnual] = useState(false)
  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",color:'#1a1a1a',minHeight:'100vh'}}>
      {/* Nav */}
      <nav style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 2.5rem',borderBottom:'0.5px solid #e5e5e5',background:'#fff'}}>
        <Link href="/" style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,fontWeight:600,letterSpacing:2,color:'#1a1a1a',textDecoration:'none'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</Link>
        <div style={{display:'flex',gap:'1.5rem',alignItems:'center'}}>
          <Link href="/discover" style={{fontSize:12,color:'#666',textDecoration:'none'}}>Discover</Link>
          <Link href="/login" style={{fontSize:12,color:'#666',textDecoration:'none'}}>Login</Link>
          <Link href="/register" style={{padding:'8px 18px',background:'#1a1a1a',color:'#f5f0e8',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none'}}>Get Started</Link>
        </div>
      </nav>

      <div style={{padding:'4rem 2.5rem',textAlign:'center'}}>
        <div style={{fontSize:11,letterSpacing:3,textTransform:'uppercase',color:'#B8860B',marginBottom:'0.75rem'}}>Transparent Pricing</div>
        <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:44,fontWeight:300,lineHeight:1.15,marginBottom:'0.75rem'}}>Simple plans for <em>every brand size</em></h1>
        <p style={{fontSize:13,color:'#999',maxWidth:440,margin:'0 auto 2rem',lineHeight:1.7}}>No hidden fees. Cancel anytime. All plans include access to Hinflu's verified creator network.</p>
        {/* Toggle */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:12,marginBottom:'3rem'}}>
          <span style={{fontSize:12,color:!annual?'#1a1a1a':'#999',fontWeight:!annual?500:400}}>Monthly</span>
          <button onClick={()=>setAnnual(a=>!a)} style={{width:44,height:24,borderRadius:12,background:'#1a1a1a',border:'none',cursor:'pointer',position:'relative',transition:'background 0.2s'}}>
            <div style={{width:18,height:18,borderRadius:'50%',background:'#f5f0e8',position:'absolute',top:3,left:annual?23:3,transition:'left 0.2s'}}/>
          </button>
          <span style={{fontSize:12,color:annual?'#1a1a1a':'#999',fontWeight:annual?500:400}}>Annual</span>
          <span style={{fontSize:10,padding:'2px 8px',background:'#fdf3de',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:8,letterSpacing:0.5}}>Save 20%</span>
        </div>

        {/* Plans */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'1px',background:'#e5e5e5',maxWidth:900,margin:'0 auto 3rem',border:'0.5px solid #e5e5e5',borderRadius:2}}>
          {PLANS.map(p => (
            <div key={p.name} style={{background:p.popular?'#fafafa':'#fff',padding:'1.5rem 1.25rem',position:'relative'}}>
              {p.popular && <div style={{position:'absolute',top:-1,left:'50%',transform:'translateX(-50%)',fontSize:10,padding:'3px 14px',background:'#B8860B',color:'#fff',letterSpacing:1,borderRadius:'0 0 2px 2px'}}>MOST POPULAR</div>}
              <div style={{fontSize:11,letterSpacing:2,textTransform:'uppercase',color:'#999',marginBottom:'0.5rem'}}>{p.name}</div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:44,fontWeight:300,lineHeight:1,marginBottom:'0.5rem'}}>
                {p.monthly ? <>${annual?p.annual:p.monthly}<span style={{fontSize:14,color:'#999'}}>/mo</span></> : <span style={{fontSize:26,paddingTop:8,display:'inline-block'}}>Custom</span>}
              </div>
              <div style={{fontSize:12,color:'#999',margin:'0.75rem 0 1.25rem',lineHeight:1.6}}>{p.desc}</div>
              <Link href="/register" style={{display:'block',padding:'10px',textAlign:'center',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none',marginBottom:'1.25rem',background:p.ctaStyle==='gold'?'#B8860B':p.ctaStyle==='dark'?'#1a1a1a':'transparent',color:p.ctaStyle==='outline'?'#1a1a1a':'#fff',border:p.ctaStyle==='outline'?'0.5px solid #e5e5e5':'none'}}>{p.cta}</Link>
              <div style={{fontSize:10,letterSpacing:1,textTransform:'uppercase',color:'#999',marginBottom:8}}>What's included</div>
              {p.features.map(f => <div key={f} style={{display:'flex',alignItems:'flex-start',gap:8,fontSize:12,marginBottom:6}}><span style={{color:'#3B6D11',fontSize:11,marginTop:1}}>✓</span>{f}</div>)}
              {p.missing.map(f => <div key={f} style={{display:'flex',alignItems:'flex-start',gap:8,fontSize:12,color:'#ccc',marginBottom:6}}><span style={{fontSize:11,marginTop:1}}>✗</span>{f}</div>)}
            </div>
          ))}
        </div>

        {/* Enterprise banner */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1.5rem 2rem',border:'0.5px solid #e5e5e5',borderRadius:2,maxWidth:900,margin:'0 auto',background:'#fafafa'}}>
          <div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:300,marginBottom:4}}>Need a custom solution?</div>
            <div style={{fontSize:12,color:'#999'}}>Talk to our team about volume pricing, API access, and white-label options.</div>
          </div>
          <Link href="/register" style={{padding:'10px 24px',background:'#1a1a1a',color:'#f5f0e8',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none',whiteSpace:'nowrap'}}>Talk to Sales ↗</Link>
        </div>
      </div>
    </div>
  )
}
