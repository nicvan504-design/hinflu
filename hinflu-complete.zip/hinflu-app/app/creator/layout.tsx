import CreatorSidebar from '@/components/layout/CreatorSidebar'
export default function CreatorLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{display:'flex',minHeight:'100vh',background:'#fff'}}>
      <CreatorSidebar />
      <main style={{marginLeft:210,flex:1,minHeight:'100vh',background:'#fff'}}>{children}</main>
    </div>
  )
}
