'use client'
import Link from 'next/link'
import { useState } from 'react'

const metrics = [
  { label:'Total Earned', value:'$18.4K', delta:'This year', dc:'#3B6D11' },
  { label:'Active Campaigns', value:'3', delta:'2 pending review', dc:'#BA7517' },
  { label:'Pending Payment', value:'$3,200', delta:'Due this week', dc:'#BA7517' },
  { label:'Profile Views', value:'1,240', delta:'+34% this month', dc:'#3B6D11' },
]

const offers = [
  { brand:'NB', brandName:'Nova Brand', camp:'Summer Glow · 2 posts + 3 stories', fee:'$1,800', avbg:'#fdf3de', avc:'#8B5E0A' },
  { brand:'VC', brandName:'Velour Co.', camp:'SS26 Collection · 1 Reel + post', fee:'$2,400', avbg:'#e8f0f5', avc:'#1a4a6b' },
  { brand:'LX', brandName:'Luxara Hotels', camp:'Dubai Stay · YouTube vlog', fee:'$3,500', avbg:'#e1f5ee', avc:'#085041' },
]

const earnings = [
  { brand:'Nova Brand', camp:'Ramadan Edit · Apr 2026', amount:'$1,200', status:'Paid', sbg:'#EAF3DE', sc:'#27500A', sb:'#97C459' },
  { brand:'Sephora MENA', camp:'Spring Glow · Mar 2026', amount:'$2,800', status:'Paid', sbg:'#EAF3DE', sc:'#27500A', sb:'#97C459' },
  { brand:'Cartier', camp:'Jewellery Launch · Mar 2026', amount:'$3,200', status:'Pending', sbg:'#FAEEDA', sc:'#633806', sb:'#EF9F27' },
  { brand:'Dubai Tourism', camp:'Visit Dubai · Feb 2026', amount:'$4,100', status:'Paid', sbg:'#EAF3DE', sc:'#27500A', sb:'#97C459' },
]

export default function CreatorDashboard() {
  const [accepted, setAccepted] = useState<number[]>([])
  const [declined, setDeclined] = useState<number[]>([])

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 1.5rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <div>
          <div style={{fontSize:15,fontWeight:500}}>Welcome back, Sofia</div>
          <div style={{fontSize:12,color:'#999',marginTop:2}}>3 new brand offers waiting for your response</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button style={{padding:'8px 16px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,cursor:'pointer',background:'#fff',fontFamily:"'DM Sans',sans-serif"}}>Edit Profile</button>
          <Link href="/creator/offers" style={{padding:'8px 18px',background:'#B8860B',color:'#fff',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none'}}>View Offers</Link>
        </div>
      </div>

      <div style={{padding:'1.25rem 1.5rem'}}>
        {/* Metrics */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:'1.25rem'}}>
          {metrics.map(m => (
            <div key={m.label} style={{background:'#fafafa',borderRadius:8,padding:'0.875rem',border:'0.5px solid #f0f0f0'}}>
              <div style={{fontSize:10,color:'#999',letterSpacing:0.5,textTransform:'uppercase',marginBottom:5}}>{m.label}</div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,fontWeight:300,lineHeight:1}}>{m.value}</div>
              <div style={{fontSize:10,marginTop:3,color:m.dc}}>{m.delta}</div>
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1rem'}}>
          {/* Offers */}
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
              <div style={{fontSize:13,fontWeight:500}}>Brand Offers</div>
              <Link href="/creator/offers" style={{fontSize:11,color:'#B8860B',textDecoration:'none'}}>View all</Link>
            </div>
            {offers.map((o,i) => (
              <div key={i} style={{padding:'0.875rem 1rem',borderBottom:'0.5px solid #f5f5f5',display:'flex',gap:10,alignItems:'flex-start'}}>
                <div style={{width:32,height:32,borderRadius:2,background:o.avbg,color:o.avc,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:500,flexShrink:0}}>{o.brand}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:12,fontWeight:500}}>{o.brandName}</div>
                  <div style={{fontSize:11,color:'#999',marginTop:1}}>{o.camp}</div>
                  {!accepted.includes(i) && !declined.includes(i) && (
                    <div style={{display:'flex',gap:6,marginTop:8}}>
                      <button onClick={()=>setAccepted(a=>[...a,i])} style={{padding:'4px 12px',background:'#EAF3DE',color:'#27500A',border:'0.5px solid #97C459',borderRadius:2,fontSize:11,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Accept</button>
                      <button onClick={()=>setDeclined(d=>[...d,i])} style={{padding:'4px 10px',background:'transparent',color:'#666',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:11,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Decline</button>
                    </div>
                  )}
                  {accepted.includes(i) && <div style={{fontSize:11,color:'#27500A',fontWeight:500,marginTop:8}}>✓ Accepted</div>}
                  {declined.includes(i) && <div style={{fontSize:11,color:'#999',marginTop:8}}>Declined</div>}
                </div>
                <div style={{fontSize:13,fontWeight:500,color:'#B8860B',flexShrink:0}}>{o.fee}</div>
              </div>
            ))}
          </div>

          {/* Earnings */}
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
              <div style={{fontSize:13,fontWeight:500}}>Earnings History</div>
              <Link href="/creator/earnings" style={{fontSize:11,color:'#B8860B',textDecoration:'none'}}>Download report</Link>
            </div>
            {earnings.map((e,i) => (
              <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5',fontSize:12}}>
                <div>
                  <div style={{fontWeight:500}}>{e.brand}</div>
                  <div style={{fontSize:11,color:'#999'}}>{e.camp}</div>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span style={{fontSize:10,padding:'2px 8px',borderRadius:1,background:e.sbg,color:e.sc,border:`0.5px solid ${e.sb}`}}>{e.status}</span>
                  <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300}}>{e.amount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Media kit */}
        <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
            <div style={{fontSize:13,fontWeight:500}}>Media Kit Snapshot</div>
            <button style={{padding:'5px 14px',background:'#B8860B',color:'#fff',border:'none',borderRadius:2,fontSize:11,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Share Media Kit</button>
          </div>
          <div style={{padding:'1rem'}}>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8,marginBottom:'1rem'}}>
              {[['2.4M','Total Followers'],['8.2%','Avg. Eng. Rate'],['47','Campaigns Done']].map(([v,l]) => (
                <div key={l} style={{background:'#fafafa',borderRadius:8,padding:'0.75rem',textAlign:'center'}}>
                  <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:300,color:'#B8860B'}}>{v}</div>
                  <div style={{fontSize:10,color:'#999',letterSpacing:0.5,marginTop:2}}>{l}</div>
                </div>
              ))}
            </div>
            <div style={{display:'flex',flexDirection:'column',gap:6}}>
              {[['Instagram','2.4M followers','8.2% eng.'],['TikTok','890K followers','11.4% eng.'],['YouTube','210K subscribers','6.8% eng.']].map(([p,f,e]) => (
                <div key={p} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'8px 0',borderBottom:'0.5px solid #f0f0f0',fontSize:12}}>
                  <div style={{fontWeight:500}}>{p}</div>
                  <div style={{fontSize:11,color:'#999'}}>{f}</div>
                  <div style={{fontSize:11,color:'#3B6D11',fontWeight:500}}>{e}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
