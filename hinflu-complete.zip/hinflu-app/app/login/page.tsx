'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('brand')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Login failed'); setLoading(false); return }
      window.location.href = data.role === 'brand' ? '/brand/dashboard' : '/creator/dashboard'
    } catch { setError('Something went wrong'); setLoading(false) }
  }

  return (
    <div style={{minHeight:'100vh',display:'grid',gridTemplateColumns:'1fr 1fr'}}>
      {/* Left panel */}
      <div style={{background:'#1a1a1a',display:'flex',flexDirection:'column',justifyContent:'center',padding:'3rem',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',top:0,left:0,right:0,bottom:0,background:'linear-gradient(135deg,#1a1a1a 0%,#2d2d2d 100%)'}}/>
        <div style={{position:'relative',zIndex:1}}>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:600,letterSpacing:2,color:'#f5f0e8',marginBottom:'3rem'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:42,fontWeight:300,color:'#f5f0e8',lineHeight:1.2,marginBottom:'1.5rem'}}>
            Welcome<br/><em style={{color:'#B8860B'}}>back</em>
          </h2>
          <p style={{fontSize:14,color:'#999',lineHeight:1.8,maxWidth:340}}>The premium marketplace where luxury brands and authentic creators build campaigns that convert.</p>
          <div style={{marginTop:'3rem',display:'flex',flexDirection:'column',gap:'1rem'}}>
            {[['48K+','Verified creators worldwide'],['94%','Campaign success rate'],['$2M+','Paid to creators monthly']].map(([val,lbl]) => (
              <div key={val} style={{display:'flex',alignItems:'center',gap:12}}>
                <span style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:300,color:'#B8860B'}}>{val}</span>
                <span style={{fontSize:12,color:'#777'}}>{lbl}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Right panel */}
      <div style={{display:'flex',flexDirection:'column',justifyContent:'center',padding:'3rem',background:'#fff'}}>
        <div style={{maxWidth:380,width:'100%',margin:'0 auto'}}>
          <div style={{marginBottom:'2rem'}}>
            <div style={{fontSize:11,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:8}}>Sign In</div>
            <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:32,fontWeight:300}}>Access your dashboard</h1>
          </div>
          {/* Role toggle */}
          <div style={{display:'flex',marginBottom:'1.5rem',border:'0.5px solid #e5e5e5',borderRadius:2,overflow:'hidden'}}>
            {['brand','creator'].map(r => (
              <button key={r} onClick={() => setRole(r)} style={{flex:1,padding:'9px',fontSize:12,fontWeight:500,border:'none',cursor:'pointer',background:role===r?'#1a1a1a':'#fff',color:role===r?'#f5f0e8':'#666',textTransform:'capitalize',fontFamily:"'DM Sans',sans-serif"}}>I am a {r}</button>
            ))}
          </div>
          <form onSubmit={handleLogin} style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Email</label>
              <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="you@example.com" required style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
            </div>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Password</label>
              <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="••••••••" required style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
            </div>
            {error && <div style={{fontSize:12,color:'#c0392b',padding:'8px 12px',background:'#fdf2f2',border:'0.5px solid #f5c6cb',borderRadius:2}}>{error}</div>}
            <button type="submit" disabled={loading} style={{background:'#1a1a1a',color:'#f5f0e8',padding:'12px',border:'none',borderRadius:2,fontSize:13,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif",opacity:loading?0.7:1}}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
          <div style={{marginTop:'1.5rem',textAlign:'center',fontSize:12,color:'#999'}}>
            Don't have an account?{' '}
            <Link href="/register" style={{color:'#B8860B',fontWeight:500,textDecoration:'none'}}>Create one free</Link>
          </div>
          <div style={{marginTop:'0.5rem',textAlign:'center'}}>
            <Link href="/forgot-password" style={{fontSize:12,color:'#999',textDecoration:'none'}}>Forgot password?</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
