import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Hinflu — Luxury Influencer Marketplace',
  description: 'Connect brands with verified creators across every tier.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
