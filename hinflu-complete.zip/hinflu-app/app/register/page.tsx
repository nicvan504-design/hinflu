'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function RegisterPage() {
  const [role, setRole] = useState('brand')
  const [form, setForm] = useState({ full_name:'', email:'', password:'' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const update = (k: string, v: string) => setForm(p => ({...p,[k]:v}))

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/auth/register', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({...form, role})
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Registration failed'); setLoading(false); return }
      window.location.href = role === 'brand' ? '/brand/dashboard' : '/creator/dashboard'
    } catch { setError('Something went wrong'); setLoading(false) }
  }

  return (
    <div style={{minHeight:'100vh',display:'grid',gridTemplateColumns:'1fr 1fr'}}>
      <div style={{background:'#1a1a1a',display:'flex',flexDirection:'column',justifyContent:'center',padding:'3rem'}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:600,letterSpacing:2,color:'#f5f0e8',marginBottom:'3rem'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</div>
        <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:42,fontWeight:300,color:'#f5f0e8',lineHeight:1.2,marginBottom:'1.5rem'}}>
          {role==='brand' ? <>Find your brand's <em style={{color:'#B8860B'}}>voice</em></> : <>Get paid to <em style={{color:'#B8860B'}}>create</em></>}
        </h2>
        <p style={{fontSize:14,color:'#999',lineHeight:1.8,maxWidth:320}}>
          {role==='brand' ? 'Access 48,000+ verified creators across every niche, platform, and tier.' : 'Connect with premium brands and earn from your authentic content.'}
        </p>
        <div style={{marginTop:'2rem',padding:'1.25rem',border:'0.5px solid #333',borderRadius:2}}>
          <div style={{fontSize:11,letterSpacing:1,textTransform:'uppercase',color:'#B8860B',marginBottom:8}}>Free for 14 days</div>
          <div style={{fontSize:13,color:'#aaa',lineHeight:1.6}}>No credit card required. Full access to all features during trial.</div>
        </div>
      </div>
      <div style={{display:'flex',flexDirection:'column',justifyContent:'center',padding:'3rem',background:'#fff'}}>
        <div style={{maxWidth:400,width:'100%',margin:'0 auto'}}>
          <div style={{marginBottom:'1.5rem'}}>
            <div style={{fontSize:11,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:8}}>Create Account</div>
            <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:30,fontWeight:300}}>Join Hinflu today</h1>
          </div>
          <div style={{display:'flex',marginBottom:'1.5rem',border:'0.5px solid #e5e5e5',borderRadius:2,overflow:'hidden'}}>
            {['brand','creator'].map(r => (
              <button key={r} onClick={()=>setRole(r)} style={{flex:1,padding:10,fontSize:12,fontWeight:500,border:'none',cursor:'pointer',background:role===r?'#1a1a1a':'#fff',color:role===r?'#f5f0e8':'#666',textTransform:'capitalize',fontFamily:"'DM Sans',sans-serif"}}>
                {r==='brand'?'I am a Brand':'I am a Creator'}
              </button>
            ))}
          </div>
          <form onSubmit={handleRegister} style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
            {[
              {k:'full_name',lbl:role==='brand'?'Brand / Company name':'Your full name',ph:role==='brand'?'Nova Brand Ltd.':'Sofia Amir',type:'text'},
              {k:'email',lbl:'Email address',ph:'you@example.com',type:'email'},
              {k:'password',lbl:'Password',ph:'Min. 8 characters',type:'password'},
            ].map(({k,lbl,ph,type}) => (
              <div key={k}>
                <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>{lbl}</label>
                <input value={form[k as keyof typeof form]} onChange={e=>update(k,e.target.value)} type={type} placeholder={ph} required style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
              </div>
            ))}
            {error && <div style={{fontSize:12,color:'#c0392b',padding:'8px 12px',background:'#fdf2f2',border:'0.5px solid #f5c6cb',borderRadius:2}}>{error}</div>}
            <button type="submit" disabled={loading} style={{background:'#B8860B',color:'#fff',padding:'12px',border:'none',borderRadius:2,fontSize:13,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif",opacity:loading?0.7:1}}>
              {loading ? 'Creating account...' : 'Create Account — Free'}
            </button>
            <p style={{fontSize:11,color:'#aaa',textAlign:'center',lineHeight:1.6}}>By registering you agree to our Terms of Service and Privacy Policy</p>
          </form>
          <div style={{marginTop:'1.5rem',textAlign:'center',fontSize:12,color:'#999'}}>
            Already have an account? <Link href="/login" style={{color:'#B8860B',fontWeight:500,textDecoration:'none'}}>Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
