'use client'
import { useState } from 'react'
import Link from 'next/link'

const STEPS = ['Personal Info','Platforms','Niche & Tier','Requirements']
const NICHES = ['Fashion','Beauty','Lifestyle','Travel','Food & Dining','Fitness & Health','Technology','Finance','Gaming','Parenting','Education','Luxury','Art & Design','Automotive','Sports']
const PLATFORMS = ['Instagram','TikTok','YouTube','X (Twitter)','LinkedIn','Pinterest']
const TIERS = [{sym:'◆',name:'Nano',range:'1K – 10K'},{sym:'◆◆',name:'Micro',range:'10K – 100K'},{sym:'◆◆◆',name:'Macro',range:'100K – 1M'},{sym:'◆◆◆◆',name:'Mega',range:'1M+'}]
const CHECKS = ['I have at least 1,000 followers on one or more platforms','My account is public and has been active for 3+ months','My average engagement rate is at least 3%','All content is original and brand-safe','I agree to Hinflu\'s Creator Terms of Service and Privacy Policy']

export default function ApplyPage() {
  const [step, setStep] = useState(1)
  const [done, setDone] = useState(false)
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([])
  const [selectedNiches, setSelectedNiches] = useState<string[]>([])
  const [selectedTier, setSelectedTier] = useState('')
  const [checked, setChecked] = useState<number[]>([])
  const allChecked = checked.length === CHECKS.length

  const toggle = (arr: string[], val: string, set: Function) => set((a: string[]) => a.includes(val) ? a.filter(x=>x!==val) : [...a,val])
  const toggleCheck = (i: number) => setChecked(c => c.includes(i) ? c.filter(x=>x!==i) : [...c,i])

  if (done) return (
    <div style={{minHeight:'100vh',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',fontFamily:"'DM Sans',sans-serif"}}>
      <div style={{width:60,height:60,borderRadius:'50%',border:'0.5px solid #d4a843',display:'flex',alignItems:'center',justifyContent:'center',marginBottom:'1.5rem',fontSize:24,color:'#B8860B'}}>✓</div>
      <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:36,fontWeight:300,marginBottom:'0.75rem'}}>Application Submitted</h2>
      <p style={{fontSize:13,color:'#999',maxWidth:420,textAlign:'center',lineHeight:1.7,marginBottom:'2rem'}}>Thank you for applying to Hinflu. Our team will review your profile and get back to you within 3–5 business days.</p>
      <span style={{fontSize:11,padding:'5px 18px',background:'#fdf3de',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:1,letterSpacing:1,textTransform:'uppercase',marginBottom:'2rem'}}>Under Review</span>
      <Link href="/login" style={{padding:'10px 24px',background:'#B8860B',color:'#fff',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none'}}>Sign In →</Link>
    </div>
  )

  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",color:'#1a1a1a',minHeight:'100vh'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1.25rem 2rem',borderBottom:'0.5px solid #e5e5e5',background:'#fff'}}>
        <Link href="/" style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,fontWeight:600,letterSpacing:2,color:'#1a1a1a',textDecoration:'none'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</Link>
        <div style={{fontSize:11,color:'#999',letterSpacing:0.5}}>Creator Application</div>
      </div>
      {/* Progress bar */}
      <div style={{height:3,background:'#f0f0f0'}}><div style={{height:3,background:'#B8860B',width:`${(step/STEPS.length)*100}%`,transition:'width 0.3s'}}/></div>
      {/* Step tabs */}
      <div style={{display:'flex',borderBottom:'0.5px solid #e5e5e5'}}>
        {STEPS.map((s,i) => (
          <div key={s} style={{flex:1,padding:'0.875rem 0.5rem',textAlign:'center',borderBottom:step===i+1?'2px solid #B8860B':'2px solid transparent',fontSize:11,color:step===i+1?'#B8860B':'#999',letterSpacing:0.5,fontWeight:step===i+1?500:400}}>
            <div style={{width:20,height:20,borderRadius:'50%',display:'inline-flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:500,background:step>i+1?'#B8860B':step===i+1?'#1a1a1a':'#f0f0f0',color:step>=i+1?'#fff':'#999',marginBottom:4}}>{step>i+1?'✓':i+1}</div>
            <div>{s}</div>
          </div>
        ))}
      </div>

      <div style={{maxWidth:600,margin:'0 auto',padding:'2rem'}}>
        {/* STEP 1 */}
        {step===1 && <>
          <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 1 of 4</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Tell us about yourself</h2>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1rem'}}>
            {[{lbl:'First name',ph:'Sofia'},{lbl:'Last name',ph:'Amir'}].map(({lbl,ph}) => (
              <div key={lbl}><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>{lbl}</label><input placeholder={ph} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
            ))}
          </div>
          <div style={{marginBottom:'1rem'}}><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Email</label><input type="email" placeholder="sofia@example.com" style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1rem'}}>
            <div><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Country</label><select style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',background:'#fff',fontFamily:"'DM Sans',sans-serif"}}><option>United Arab Emirates</option><option>Saudi Arabia</option><option>United Kingdom</option><option>United States</option><option>India</option><option>Pakistan</option></select></div>
            <div><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Date of birth</label><input type="date" style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
          </div>
          <div><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Short Bio</label><textarea rows={3} placeholder="Tell brands what makes you unique..." style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif",resize:'vertical'}}/></div>
        </>}

        {/* STEP 2 */}
        {step===2 && <>
          <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 2 of 4</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Connect your platforms</h2>
          <div style={{marginBottom:'1.25rem'}}>
            <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Platforms</label>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
              {PLATFORMS.map(p => (
                <div key={p} onClick={()=>toggle(selectedPlatforms,p,setSelectedPlatforms)} style={{border:`0.5px solid ${selectedPlatforms.includes(p)?'#B8860B':'#e5e5e5'}`,background:selectedPlatforms.includes(p)?'#fdf8ee':'#fff',borderRadius:2,padding:'12px 8px',textAlign:'center',cursor:'pointer'}}>
                  <div style={{fontSize:12,fontWeight:500,color:selectedPlatforms.includes(p)?'#8B5E0A':'#1a1a1a'}}>{p}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{marginBottom:'1rem'}}><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Primary Profile URL</label><input type="url" placeholder="https://instagram.com/yourhandle" style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem'}}>
            <div><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Total Followers</label><input type="number" placeholder="42000" style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
            <div><label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Avg. Engagement Rate (%)</label><input type="number" placeholder="8.5" step={0.1} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/></div>
          </div>
        </>}

        {/* STEP 3 */}
        {step===3 && <>
          <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 3 of 4</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Your niche & influence tier</h2>
          <div style={{marginBottom:'1.25rem'}}>
            <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Content niche (select all that apply)</label>
            <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
              {NICHES.map(n => (
                <div key={n} onClick={()=>toggle(selectedNiches,n,setSelectedNiches)} style={{fontSize:11,padding:'5px 12px',border:`0.5px solid ${selectedNiches.includes(n)?'#B8860B':'#e5e5e5'}`,background:selectedNiches.includes(n)?'#fdf8ee':'#fff',color:selectedNiches.includes(n)?'#8B5E0A':'#666',borderRadius:2,cursor:'pointer',fontWeight:selectedNiches.includes(n)?500:400}}>{n}</div>
              ))}
            </div>
          </div>
          <div>
            <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Influencer tier</label>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8}}>
              {TIERS.map(t => (
                <div key={t.name} onClick={()=>setSelectedTier(t.name)} style={{border:`0.5px solid ${selectedTier===t.name?'#B8860B':'#e5e5e5'}`,background:selectedTier===t.name?'#fdf8ee':'#fff',borderRadius:2,padding:'1rem',textAlign:'center',cursor:'pointer'}}>
                  <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:'#B8860B',marginBottom:4}}>{t.sym}</div>
                  <div style={{fontSize:11,fontWeight:500,color:selectedTier===t.name?'#8B5E0A':'#1a1a1a'}}>{t.name}</div>
                  <div style={{fontSize:10,color:'#999'}}>{t.range}</div>
                </div>
              ))}
            </div>
          </div>
        </>}

        {/* STEP 4 */}
        {step===4 && <>
          <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 4 of 4</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Confirm your eligibility</h2>
          <div style={{display:'flex',flexDirection:'column',gap:10,marginBottom:'1.25rem'}}>
            {CHECKS.map((c,i) => (
              <div key={i} onClick={()=>toggleCheck(i)} style={{display:'flex',alignItems:'flex-start',gap:12,padding:'12px 14px',border:`0.5px solid ${checked.includes(i)?'#B8860B':'#e5e5e5'}`,background:checked.includes(i)?'#fdf8ee':'#fafafa',borderRadius:2,cursor:'pointer'}}>
                <div style={{width:18,height:18,minWidth:18,borderRadius:2,border:`0.5px solid ${checked.includes(i)?'#B8860B':'#e5e5e5'}`,background:checked.includes(i)?'#B8860B':'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,color:'#fff',marginTop:1}}>{checked.includes(i)?'✓':''}</div>
                <div style={{fontSize:13,lineHeight:1.5}}>{c}</div>
              </div>
            ))}
          </div>
          <div style={{fontSize:12,color:allChecked?'#3B6D11':'#999',marginBottom:'1rem'}}>{allChecked?'✓ All requirements confirmed. Ready to submit.':'Check all boxes above to submit your application.'}</div>
        </>}

        {/* Nav */}
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:'2rem',paddingTop:'1rem',borderTop:'0.5px solid #e5e5e5'}}>
          {step>1 ? <button onClick={()=>setStep(s=>s-1)} style={{padding:'10px 20px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,cursor:'pointer',background:'#fff',fontFamily:"'DM Sans',sans-serif"}}>← Back</button> : <div/>}
          {step<4 ? (
            <button onClick={()=>setStep(s=>s+1)} style={{padding:'10px 24px',background:'#1a1a1a',color:'#f5f0e8',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Continue →</button>
          ) : (
            <button onClick={()=>setDone(true)} disabled={!allChecked} style={{padding:'10px 28px',background:allChecked?'#B8860B':'#ccc',color:'#fff',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:allChecked?'pointer':'default',fontFamily:"'DM Sans',sans-serif"}}>Submit Application</button>
          )}
        </div>
      </div>
    </div>
  )
}
