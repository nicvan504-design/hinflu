import Link from 'next/link'

export default function LandingPage() {
  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",color:'#1a1a1a',minHeight:'100vh'}}>
      {/* NAV */}
      <nav style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1.25rem 2.5rem',borderBottom:'0.5px solid #e5e5e5',background:'#fff',position:'sticky',top:0,zIndex:100}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:24,fontWeight:600,letterSpacing:2}}>
          H<span style={{color:'#B8860B'}}>.</span>INFLU
        </div>
        <div style={{display:'flex',gap:'2rem',alignItems:'center'}}>
          <Link href="/discover" style={{fontSize:13,color:'#666',textDecoration:'none'}}>Discover</Link>
          <Link href="/pricing" style={{fontSize:13,color:'#666',textDecoration:'none'}}>Pricing</Link>
          <Link href="/login" style={{fontSize:13,color:'#666',textDecoration:'none'}}>Login</Link>
          <Link href="/register" style={{padding:'9px 22px',background:'#1a1a1a',color:'#f5f0e8',borderRadius:2,fontSize:13,fontWeight:500,textDecoration:'none'}}>Get Started</Link>
        </div>
      </nav>

      {/* HERO */}
      <section style={{padding:'6rem 2.5rem 5rem',display:'grid',gridTemplateColumns:'1fr 1fr',gap:'4rem',alignItems:'center',maxWidth:1100,margin:'0 auto'}}>
        <div>
          <div style={{display:'inline-block',fontSize:11,letterSpacing:3,textTransform:'uppercase',color:'#B8860B',border:'0.5px solid #B8860B',padding:'5px 14px',marginBottom:'1.5rem',borderRadius:1}}>Premium Influencer Marketplace</div>
          <h1 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:58,fontWeight:300,lineHeight:1.1,marginBottom:'1.5rem'}}>
            Where <em style={{color:'#B8860B'}}>Brands</em> Meet Their Perfect Voice
          </h1>
          <p style={{fontSize:15,fontWeight:300,lineHeight:1.8,color:'#666',marginBottom:'2.5rem',maxWidth:400}}>
            Hinflu connects ambitious brands with authentic creators across every tier — from nano to mega. Curated, verified, and performance-driven.
          </p>
          <div style={{display:'flex',gap:'1rem'}}>
            <Link href="/register?role=brand" style={{background:'#1a1a1a',color:'#f5f0e8',padding:'14px 32px',borderRadius:2,fontSize:13,fontWeight:500,textDecoration:'none'}}>Hire an Influencer</Link>
            <Link href="/apply" style={{background:'transparent',color:'#1a1a1a',border:'0.5px solid #ccc',padding:'14px 32px',borderRadius:2,fontSize:13,textDecoration:'none'}}>Join as Creator</Link>
          </div>
        </div>
        {/* Hero visual */}
        <div style={{position:'relative',height:380}}>
          {[
            {initials:'SA',name:'Sofia Amir',niche:'Fashion · Lifestyle',followers:'2.4M',eng:'8.2%',tier:'Mega',top:0,left:0,bg:'#fdf3de',color:'#8B5E0A'},
            {initials:'JK',name:'James Ko',niche:'Tech · Finance',followers:'180K',eng:'12.4%',tier:'Macro',top:70,left:80,bg:'#e8f0f5',color:'#1a4a6b'},
            {initials:'NA',name:'Nour Al-Rashid',niche:'Beauty · Wellness',followers:'42K',eng:'19.1%',tier:'Micro',top:140,left:160,bg:'#f0e8f5',color:'#5a1a7a'},
          ].map((c,i) => (
            <div key={i} style={{position:'absolute',top:c.top,left:c.left,background:'#fff',border:'0.5px solid #e5e5e5',borderRadius:4,padding:'1.25rem',width:230,boxShadow:'0 2px 12px rgba(0,0,0,0.06)'}}>
              <div style={{width:44,height:44,borderRadius:'50%',background:c.bg,color:c.color,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Cormorant Garamond',serif",fontSize:17,fontWeight:600,marginBottom:10}}>{c.initials}</div>
              <div style={{fontSize:13,fontWeight:500,marginBottom:2}}>{c.name}</div>
              <div style={{fontSize:11,color:'#999',marginBottom:10}}>{c.niche}</div>
              <div style={{display:'flex',gap:16}}>
                <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:600}}>{c.followers}</div><div style={{fontSize:10,color:'#999',textTransform:'uppercase',letterSpacing:0.5}}>Followers</div></div>
                <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:600}}>{c.eng}</div><div style={{fontSize:10,color:'#999',textTransform:'uppercase',letterSpacing:0.5}}>Eng. Rate</div></div>
              </div>
              <div style={{marginTop:10,fontSize:10,padding:'3px 10px',background:'#fdf3de',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:1,display:'inline-block'}}>{c.tier} Influencer</div>
            </div>
          ))}
        </div>
      </section>

      {/* STATS BAR */}
      <div style={{borderTop:'0.5px solid #e5e5e5',borderBottom:'0.5px solid #e5e5e5',padding:'2rem 2.5rem',display:'grid',gridTemplateColumns:'repeat(4,1fr)',background:'#fafafa'}}>
        {[['48K+','Verified Creators'],['3,200+','Brand Campaigns'],['94%','Success Rate'],['120+','Countries']].map(([val,lbl],i) => (
          <div key={i} style={{textAlign:'center',borderRight:i<3?'0.5px solid #e5e5e5':'none'}}>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:38,fontWeight:300,color:'#B8860B',lineHeight:1}}>{val}</div>
            <div style={{fontSize:12,color:'#999',marginTop:4}}>{lbl}</div>
          </div>
        ))}
      </div>

      {/* HOW IT WORKS */}
      <section style={{padding:'5rem 2.5rem',maxWidth:1100,margin:'0 auto'}}>
        <div style={{textAlign:'center',marginBottom:'3rem'}}>
          <div style={{fontSize:11,letterSpacing:3,textTransform:'uppercase',color:'#B8860B',marginBottom:'0.75rem'}}>The Process</div>
          <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:40,fontWeight:300}}>How Hinflu Works</h2>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:2,background:'#e5e5e5'}}>
          {[
            ['01','Post Your Campaign','Define your goals, budget, and creator profile. Our AI matching engine gets to work instantly.'],
            ['02','Discover & Shortlist','Browse verified creator profiles with real analytics — engagement rates, audience demographics, and past campaigns.'],
            ['03','Collaborate & Track','Approve content, manage contracts, release payments, and track live campaign performance.'],
          ].map(([num,title,desc],i) => (
            <div key={i} style={{background:'#fafafa',padding:'2.5rem 2rem'}}>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:48,fontWeight:300,color:'#d4c5a0',lineHeight:1,marginBottom:'1.5rem'}}>{num}</div>
              <div style={{fontSize:15,fontWeight:500,marginBottom:'0.75rem'}}>{title}</div>
              <div style={{fontSize:13,lineHeight:1.7,color:'#666'}}>{desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{padding:'5rem 2.5rem',textAlign:'center',borderTop:'0.5px solid #e5e5e5'}}>
        <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:46,fontWeight:300,lineHeight:1.15,marginBottom:'1.5rem'}}>Ready to Elevate<br/>Your Brand's Voice?</h2>
        <p style={{fontSize:14,color:'#666',maxWidth:460,margin:'0 auto 2.5rem',lineHeight:1.7}}>Join thousands of brands running successful influencer campaigns on Hinflu.</p>
        <div style={{display:'flex',gap:'1rem',justifyContent:'center'}}>
          <Link href="/register?role=brand" style={{background:'#B8860B',color:'#fff',padding:'14px 36px',borderRadius:2,fontSize:13,fontWeight:500,textDecoration:'none'}}>Start as a Brand ↗</Link>
          <Link href="/apply" style={{background:'transparent',color:'#1a1a1a',border:'0.5px solid #ccc',padding:'14px 32px',borderRadius:2,fontSize:13,textDecoration:'none'}}>Apply as Creator ↗</Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{borderTop:'0.5px solid #e5e5e5',padding:'2rem 2.5rem',display:'flex',alignItems:'center',justifyContent:'space-between',background:'#fafafa'}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:600,letterSpacing:2}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</div>
        <div style={{display:'flex',gap:'1.5rem'}}>
          {['About','Privacy','Terms','Contact'].map(l => <a key={l} href="#" style={{fontSize:12,color:'#999',textDecoration:'none'}}>{l}</a>)}
        </div>
        <div style={{fontSize:11,color:'#999'}}>© 2026 Hinflu. All rights reserved.</div>
      </footer>
    </div>
  )
}
