'use client'
import { useState } from 'react'
import Link from 'next/link'

const CREATORS = [
  { id:'1', initials:'SA', name:'Sofia Amir', niche:'Fashion · Lifestyle', country:'Dubai, UAE', tier:'mega', tierbg:'#f0e8f5', tierc:'#5a1a7a', followers:'2.4M', eng:'8.2%', campaigns:47, avbg:'#fdf3de', avc:'#8B5E0A', platforms:['Instagram','TikTok'], engNum:8.2 },
  { id:'2', initials:'JK', name:'James Ko', niche:'Tech · Finance', country:'London, UK', tier:'macro', tierbg:'#e8f0f5', tierc:'#1a4a6b', followers:'180K', eng:'12.4%', campaigns:23, avbg:'#e8f0f5', avc:'#1a4a6b', platforms:['YouTube','X'], engNum:12.4 },
  { id:'3', initials:'NA', name:'Nour Al-Rashid', niche:'Beauty · Wellness', country:'Riyadh, KSA', tier:'micro', tierbg:'#fdf3de', tierc:'#8B5E0A', followers:'42K', eng:'19.1%', campaigns:15, avbg:'#f0e8f5', avc:'#5a1a7a', platforms:['Instagram'], engNum:19.1 },
  { id:'4', initials:'RL', name:'Rania Levi', niche:'Food · Travel', country:'Dubai, UAE', tier:'micro', tierbg:'#fdf3de', tierc:'#8B5E0A', followers:'67K', eng:'14.8%', campaigns:31, avbg:'#e1f5ee', avc:'#085041', platforms:['TikTok','Instagram'], engNum:14.8 },
  { id:'5', initials:'MA', name:'Maya Ahn', niche:'Luxury · Fashion', country:'Paris, France', tier:'macro', tierbg:'#e8f0f5', tierc:'#1a4a6b', followers:'890K', eng:'7.6%', campaigns:58, avbg:'#fbeaf0', avc:'#72243e', platforms:['Instagram','YouTube'], engNum:7.6 },
  { id:'6', initials:'ZM', name:'Zaid Malik', niche:'Fitness · Lifestyle', country:'Dubai, UAE', tier:'nano', tierbg:'#e1f5ee', tierc:'#085041', followers:'6.2K', eng:'22.3%', campaigns:8, avbg:'#faeeda', avc:'#633806', platforms:['Instagram'], engNum:22.3 },
  { id:'7', initials:'LR', name:'Lara Russo', niche:'Lifestyle · Beauty', country:'Milan, Italy', tier:'macro', tierbg:'#e8f0f5', tierc:'#1a4a6b', followers:'320K', eng:'9.1%', campaigns:34, avbg:'#fdf3de', avc:'#8B5E0A', platforms:['Instagram','TikTok'], engNum:9.1 },
  { id:'8', initials:'KP', name:'Kai Patel', niche:'Tech · Gaming', country:'Mumbai, India', tier:'micro', tierbg:'#fdf3de', tierc:'#8B5E0A', followers:'88K', eng:'16.2%', campaigns:19, avbg:'#e8f0f5', avc:'#1a4a6b', platforms:['YouTube','TikTok'], engNum:16.2 },
  { id:'9', initials:'FF', name:'Fatima Farooq', niche:'Fashion · Luxury', country:'Dubai, UAE', tier:'mega', tierbg:'#f0e8f5', tierc:'#5a1a7a', followers:'1.8M', eng:'6.9%', campaigns:62, avbg:'#f0e8f5', avc:'#5a1a7a', platforms:['Instagram','YouTube'], engNum:6.9 },
]

const NICHES = ['All','Fashion','Beauty','Tech','Travel','Food','Fitness','Luxury','Finance','Gaming']
const TIERS = ['All','Nano','Micro','Macro','Mega']
const PLATFORMS = ['All','Instagram','TikTok','YouTube','X']

export default function DiscoverPage() {
  const [search, setSearch] = useState('')
  const [niche, setNiche] = useState('All')
  const [tier, setTier] = useState('All')
  const [platform, setPlatform] = useState('All')
  const [minEng, setMinEng] = useState(0)
  const [shortlisted, setShortlisted] = useState<string[]>([])
  const [sort, setSort] = useState('engagement')

  const filtered = CREATORS.filter(c => {
    if (search && !c.name.toLowerCase().includes(search.toLowerCase()) && !c.niche.toLowerCase().includes(search.toLowerCase())) return false
    if (niche !== 'All' && !c.niche.toLowerCase().includes(niche.toLowerCase())) return false
    if (tier !== 'All' && c.tier !== tier.toLowerCase()) return false
    if (platform !== 'All' && !c.platforms.includes(platform)) return false
    if (c.engNum < minEng) return false
    return true
  }).sort((a,b) => sort==='engagement' ? b.engNum-a.engNum : sort==='followers_desc' ? parseFloat(b.followers)-parseFloat(a.followers) : 0)

  const toggleShortlist = (id: string) => setShortlisted(s => s.includes(id) ? s.filter(x=>x!==id) : [...s,id])

  const Chip = ({label, selected, onClick}: {label:string,selected:boolean,onClick:()=>void}) => (
    <button onClick={onClick} style={{fontSize:11,padding:'5px 12px',border:`0.5px solid ${selected?'#B8860B':'#e5e5e5'}`,background:selected?'#fdf8ee':'#fff',color:selected?'#8B5E0A':'#666',borderRadius:2,cursor:'pointer',fontFamily:"'DM Sans',sans-serif",fontWeight:selected?500:400}}>{label}</button>
  )

  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",color:'#1a1a1a'}}>
      {/* Topbar */}
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 1.5rem',borderBottom:'0.5px solid #e5e5e5',background:'#fff',position:'sticky',top:0,zIndex:10}}>
        <Link href="/" style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,fontWeight:600,letterSpacing:2,color:'#1a1a1a',textDecoration:'none'}}>H<span style={{color:'#B8860B'}}>.</span>INFLU</Link>
        <div style={{display:'flex',flex:1,maxWidth:400,margin:'0 1.5rem',border:'0.5px solid #e5e5e5',borderRadius:2,overflow:'hidden',background:'#fff'}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by name, niche, or location..." style={{flex:1,border:'none',padding:'9px 14px',fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
          <button style={{background:'#1a1a1a',color:'#f5f0e8',border:'none',padding:'9px 18px',fontSize:12,cursor:'pointer'}}>Search</button>
        </div>
        <div style={{fontSize:12,color:'#999'}}>{filtered.length.toLocaleString()} creators found</div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'210px 1fr'}}>
        {/* Filters */}
        <div style={{background:'#fafafa',borderRight:'0.5px solid #e5e5e5',padding:'0',minHeight:'calc(100vh - 57px)'}}>
          {[
            {title:'Influencer Tier', items:TIERS, val:tier, set:setTier},
            {title:'Niche', items:NICHES, val:niche, set:setNiche},
            {title:'Platform', items:PLATFORMS, val:platform, set:setPlatform},
          ].map(({title,items,val,set}) => (
            <div key={title} style={{padding:'1rem',borderBottom:'0.5px solid #e5e5e5'}}>
              <div style={{fontSize:10,letterSpacing:1.5,textTransform:'uppercase',color:'#999',marginBottom:10}}>{title}</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:5}}>
                {items.map(i => <Chip key={i} label={i} selected={val===i} onClick={()=>set(i)}/>)}
              </div>
            </div>
          ))}
          <div style={{padding:'1rem',borderBottom:'0.5px solid #e5e5e5'}}>
            <div style={{fontSize:10,letterSpacing:1.5,textTransform:'uppercase',color:'#999',marginBottom:8}}>Min. Eng. Rate</div>
            <input type="range" min={0} max={25} value={minEng} onChange={e=>setMinEng(parseInt(e.target.value))} style={{width:'100%'}}/>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:'#999',marginTop:4}}><span>0%</span><span style={{color:'#1a1a1a',fontWeight:500}}>{minEng}%+</span></div>
          </div>
          <button onClick={()=>{setSearch('');setNiche('All');setTier('All');setPlatform('All');setMinEng(0)}} style={{margin:'1rem',fontSize:11,color:'#B8860B',background:'transparent',border:'none',cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Reset all filters</button>
        </div>

        {/* Grid */}
        <div>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1.25rem',borderBottom:'0.5px solid #e5e5e5'}}>
            <div style={{fontSize:12,color:'#999'}}>{filtered.length} creators</div>
            <div style={{display:'flex',alignItems:'center',gap:8,fontSize:12,color:'#666'}}>
              Sort by:
              <select value={sort} onChange={e=>setSort(e.target.value)} style={{border:'0.5px solid #e5e5e5',background:'#fff',padding:'5px 10px',fontSize:11,borderRadius:2,outline:'none',fontFamily:"'DM Sans',sans-serif"}}>
                <option value="engagement">Engagement rate</option>
                <option value="followers_desc">Followers (high→low)</option>
              </select>
            </div>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'1px',background:'#e5e5e5'}}>
            {filtered.map(c => (
              <div key={c.id} style={{background:'#fff',padding:'1.25rem'}}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:10}}>
                  <div style={{width:44,height:44,borderRadius:'50%',background:c.avbg,color:c.avc,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Cormorant Garamond',serif",fontSize:17,fontWeight:600}}>{c.initials}</div>
                  <button onClick={()=>toggleShortlist(c.id)} style={{width:28,height:28,borderRadius:'50%',border:'0.5px solid #e5e5e5',background:shortlisted.includes(c.id)?'#fdf3de':'transparent',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,color:shortlisted.includes(c.id)?'#B8860B':'#ccc'}}>★</button>
                </div>
                <div style={{fontSize:13,fontWeight:500,marginBottom:2}}>{c.name}</div>
                <div style={{fontSize:11,color:'#999',marginBottom:8}}>{c.niche} · {c.country}</div>
                <div style={{display:'flex',gap:12,marginBottom:8}}>
                  {[['Followers',c.followers],['Eng.',c.eng],['Campaigns',c.campaigns]].map(([l,v]) => (
                    <div key={l as string}><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:17,fontWeight:300,lineHeight:1}}>{v}</div><div style={{fontSize:10,color:'#999',letterSpacing:0.3}}>{l}</div></div>
                  ))}
                </div>
                {/* Engagement bar */}
                <div style={{height:3,background:'#f0f0f0',borderRadius:2,marginBottom:8,overflow:'hidden'}}>
                  <div style={{height:3,background:'#B8860B',borderRadius:2,width:`${Math.min(c.engNum*4,100)}%`}}/>
                </div>
                <div style={{display:'flex',gap:4,flexWrap:'wrap',marginBottom:10}}>
                  <span style={{fontSize:10,padding:'2px 8px',background:c.tierbg,color:c.tierc,border:`0.5px solid ${c.tierc}55`,borderRadius:1}}>{c.tier.charAt(0).toUpperCase()+c.tier.slice(1)}</span>
                  {c.platforms.map(p => <span key={p} style={{fontSize:10,padding:'2px 8px',background:'#f5f5f5',color:'#666',borderRadius:1}}>{p}</span>)}
                </div>
                <Link href={`/discover/${c.id}`} style={{display:'block',width:'100%',padding:'7px',textAlign:'center',fontSize:11,border:'0.5px solid #e5e5e5',borderRadius:2,textDecoration:'none',color:'#333',background:'#fff',transition:'all 0.15s'}}>View Profile</Link>
              </div>
            ))}
          </div>
          {filtered.length === 0 && (
            <div style={{textAlign:'center',padding:'4rem',color:'#999'}}>
              <div style={{fontSize:32,marginBottom:'1rem'}}>◉</div>
              <div style={{fontSize:15,fontWeight:500,marginBottom:8}}>No creators found</div>
              <div style={{fontSize:13}}>Try adjusting your filters</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
