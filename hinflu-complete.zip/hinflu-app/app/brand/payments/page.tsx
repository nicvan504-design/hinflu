'use client'
import { useState } from 'react'

const TABS = ['Contracts','Escrow & Milestones','Invoice History']

const CONTRACTS = [
  { name:'Sofia Amir', campaign:'Summer Glow · May 2026', status:'Signed', statusBg:'#EAF3DE', statusC:'#27500A', statusBorder:'#97C459', value:'$1,800', signed:'Apr 18' },
  { name:'James Ko', campaign:'Tech Launch Q3', status:'Signed', statusBg:'#EAF3DE', statusC:'#27500A', statusBorder:'#97C459', value:'$2,400', signed:'Apr 20' },
  { name:'Nour Al-Rashid', campaign:'Ramadan Edit', status:'Pending', statusBg:'#FAEEDA', statusC:'#633806', statusBorder:'#EF9F27', value:'$900', signed:'—' },
  { name:'Rania Levi', campaign:'Fall Collection', status:'Signed', statusBg:'#EAF3DE', statusC:'#27500A', statusBorder:'#97C459', value:'$650', signed:'Mar 10' },
  { name:'Maya Ahn', campaign:'SS26 Launch · Paris', status:'Pending', statusBg:'#FAEEDA', statusC:'#633806', statusBorder:'#EF9F27', value:'$3,200', signed:'—' },
]

const INVOICES = [
  { num:'INV-0042', desc:'Sofia Amir — Summer Glow (50%)', sub:'Campaign payment · Escrow release', date:'Apr 22', amount:'$900' },
  { num:'INV-0041', desc:'Rania Levi — Fall Collection', sub:'Final payment · Campaign complete', date:'Apr 15', amount:'$650' },
  { num:'INV-0040', desc:'Nour Al-Rashid — Ramadan Edit', sub:'Milestone 1 release', date:'Apr 10', amount:'$450' },
  { num:'INV-0039', desc:'Hinflu Pro Plan — April 2026', sub:'Monthly subscription', date:'Apr 1', amount:'$299' },
  { num:'INV-0038', desc:'Sofia Amir — Ramadan Edit', sub:'Full campaign payment', date:'Mar 28', amount:'$1,200' },
]

export default function PaymentsPage() {
  const [tab, setTab] = useState(0)
  const [released, setReleased] = useState<{[k:string]:boolean}>({})

  const metrics = [
    {label:'Active Contracts', value:'6', delta:'All in good standing', dc:'#3B6D11'},
    {label:'Total Contract Value', value:'$28.4K', delta:'This quarter', dc:'#999'},
    {label:'Pending Signatures', value:'2', delta:'Awaiting creator', dc:'#BA7517'},
    {label:'In Escrow', value:'$5,100', delta:'Held securely', dc:'#1a4a6b'},
  ]

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 1.5rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <div>
          <div style={{fontSize:15,fontWeight:500}}>Contracts & Payments</div>
          <div style={{fontSize:12,color:'#999',marginTop:2}}>Manage escrow, milestones, and invoices</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button style={{padding:'8px 16px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,cursor:'pointer',background:'#fff',fontFamily:"'DM Sans',sans-serif"}}>Download All Invoices</button>
          <button style={{padding:'8px 18px',background:'#B8860B',color:'#fff',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>+ New Contract</button>
        </div>
      </div>

      <div style={{padding:'1.25rem 1.5rem'}}>
        {/* Metrics */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:'1.25rem'}}>
          {metrics.map(m => (
            <div key={m.label} style={{background:'#fafafa',borderRadius:8,padding:'0.875rem',border:'0.5px solid #f0f0f0'}}>
              <div style={{fontSize:10,color:'#999',letterSpacing:0.5,textTransform:'uppercase',marginBottom:5}}>{m.label}</div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,fontWeight:300,lineHeight:1}}>{m.value}</div>
              <div style={{fontSize:10,marginTop:3,color:m.dc}}>{m.delta}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{display:'flex',borderBottom:'0.5px solid #e5e5e5',marginBottom:'1.25rem'}}>
          {TABS.map((t,i) => (
            <button key={t} onClick={()=>setTab(i)} style={{padding:'10px 1.5rem',fontSize:12,cursor:'pointer',border:'none',borderBottom:tab===i?'2px solid #B8860B':'2px solid transparent',color:tab===i?'#B8860B':'#666',background:'transparent',fontWeight:tab===i?500:400,fontFamily:"'DM Sans',sans-serif",marginBottom:-1}}>{t}</button>
          ))}
        </div>

        {/* CONTRACTS TAB */}
        {tab===0 && (
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'grid',gridTemplateColumns:'1fr 90px 80px 80px 90px',gap:8,padding:'10px 1rem',background:'#fafafa',fontSize:10,letterSpacing:0.5,textTransform:'uppercase',color:'#999',borderBottom:'0.5px solid #e5e5e5'}}>
              <div>Creator & Campaign</div><div>Status</div><div>Value</div><div>Signed</div><div>Action</div>
            </div>
            {CONTRACTS.map((c,i) => (
              <div key={i} style={{display:'grid',gridTemplateColumns:'1fr 90px 80px 80px 90px',alignItems:'center',gap:8,padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5',fontSize:12}}>
                <div><div style={{fontWeight:500}}>{c.name}</div><div style={{fontSize:11,color:'#999'}}>{c.campaign}</div></div>
                <div><span style={{fontSize:10,padding:'3px 8px',borderRadius:1,background:c.statusBg,color:c.statusC,border:`0.5px solid ${c.statusBorder}`}}>{c.status}</span></div>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300}}>{c.value}</div>
                <div style={{fontSize:11,color:'#999'}}>{c.signed}</div>
                <div style={{fontSize:11,color:'#B8860B',cursor:'pointer'}}>{c.status==='Signed'?'View PDF':'Send Reminder'}</div>
              </div>
            ))}
          </div>
        )}

        {/* ESCROW TAB */}
        {tab===1 && (
          <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
            {[
              {name:'Sofia Amir',camp:'Summer Glow · Instagram + TikTok',total:'$1,800',milestones:[
                {label:'Contract signed & brief delivered',amt:'$0',status:'done'},
                {label:'First draft approved (50%)',amt:'$900',status:'done'},
                {label:'Content published & verified',amt:'$900',status:'ready'},
              ]},
              {name:'James Ko',camp:'Tech Launch Q3 · YouTube + posts',total:'$2,400',milestones:[
                {label:'Contract signed & brief delivered',amt:'$0',status:'done'},
                {label:'Script approved (30%)',amt:'$720',status:'active'},
                {label:'Video published & analytics shared',amt:'$1,680',status:'locked'},
              ]},
            ].map((e,ei) => (
              <div key={ei} style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
                <div style={{padding:'1rem',borderBottom:'0.5px solid #e5e5e5',display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                  <div>
                    <div style={{fontSize:13,fontWeight:500}}>{e.name}</div>
                    <div style={{fontSize:11,color:'#999',marginTop:2}}>{e.camp}</div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:300,color:'#B8860B'}}>{e.total}</div>
                    <div style={{fontSize:10,color:'#999'}}>Total contract</div>
                  </div>
                </div>
                <div style={{padding:'1rem',display:'flex',flexDirection:'column',gap:6}}>
                  {e.milestones.map((m,mi) => {
                    const key = `${ei}-${mi}`
                    const isReleased = released[key]
                    return (
                      <div key={mi} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',background:'#fafafa',borderRadius:2,fontSize:12}}>
                        <div style={{width:10,height:10,borderRadius:'50%',flexShrink:0,background:m.status==='done'?'#3B6D11':m.status==='ready'||m.status==='active'?'#B8860B':'#ccc'}}/>
                        <div style={{flex:1}}>{m.label}</div>
                        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:15,fontWeight:300,minWidth:50,textAlign:'right'}}>{m.amt}</div>
                        {m.status==='done' && <span style={{fontSize:10,padding:'2px 8px',background:'#EAF3DE',color:'#27500A',border:'0.5px solid #97C459',borderRadius:1}}>Released</span>}
                        {(m.status==='ready'||m.status==='active') && !isReleased && <button onClick={()=>setReleased(r=>({...r,[key]:true}))} style={{fontSize:11,padding:'4px 12px',background:'#B8860B',color:'#fff',border:'none',borderRadius:2,cursor:'pointer',fontFamily:"'DM Sans',sans-serif",whiteSpace:'nowrap'}}>Release {m.amt}</button>}
                        {(m.status==='ready'||m.status==='active') && isReleased && <span style={{fontSize:10,padding:'2px 8px',background:'#EAF3DE',color:'#27500A',border:'0.5px solid #97C459',borderRadius:1}}>Released ✓</span>}
                        {m.status==='locked' && <span style={{fontSize:10,padding:'2px 8px',background:'#f5f5f5',color:'#999',borderRadius:1}}>Locked</span>}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* INVOICES TAB */}
        {tab===2 && (
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'grid',gridTemplateColumns:'80px 1fr 80px 80px 60px',gap:8,padding:'10px 1rem',background:'#fafafa',fontSize:10,letterSpacing:0.5,textTransform:'uppercase',color:'#999',borderBottom:'0.5px solid #e5e5e5'}}>
              <div>Invoice #</div><div>Description</div><div>Date</div><div>Amount</div><div>PDF</div>
            </div>
            {INVOICES.map((inv,i) => (
              <div key={i} style={{display:'grid',gridTemplateColumns:'80px 1fr 80px 80px 60px',alignItems:'center',gap:8,padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5',fontSize:12}}>
                <div style={{fontWeight:500,color:'#B8860B',fontSize:11}}>{inv.num}</div>
                <div><div style={{fontWeight:500}}>{inv.desc}</div><div style={{fontSize:11,color:'#999'}}>{inv.sub}</div></div>
                <div style={{fontSize:11,color:'#999'}}>{inv.date}</div>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300}}>{inv.amount}</div>
                <div style={{fontSize:11,color:'#999',cursor:'pointer'}}>PDF ↓</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
