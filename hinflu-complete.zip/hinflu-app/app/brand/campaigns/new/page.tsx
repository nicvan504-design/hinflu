'use client'
import { useState } from 'react'
import Link from 'next/link'

const STEPS = ['Campaign Basics','Objective','Budget & Dates','Creator Criteria','Review & Launch']

const OBJECTIVES = [
  {id:'brand_awareness',label:'Brand Awareness',desc:'Reach new audiences'},
  {id:'product_sales',label:'Product Sales',desc:'Drive conversions'},
  {id:'engagement',label:'Engagement',desc:'Likes, comments, shares'},
  {id:'follower_growth',label:'Follower Growth',desc:'Grow your audience'},
  {id:'app_installs',label:'App Installs',desc:'Drive downloads'},
  {id:'content_creation',label:'Content Creation',desc:'UGC for your brand'},
]

export default function CampaignWizard() {
  const [step, setStep] = useState(1)
  const [launched, setLaunched] = useState(false)
  const [form, setForm] = useState({
    title:'', product_name:'', brief:'', industry:'Fashion', region:'UAE',
    objective:'brand_awareness', platforms:['instagram'], deliverables:['instagram_posts','stories'],
    budget:5000, start_date:'', end_date:'', requirements:'',
    min_followers:10000, min_engagement:5, tiers:['micro','macro'], niches:['fashion','beauty'],
  })

  const update = (k: string, v: any) => setForm(p => ({...p,[k]:v}))
  const toggle = (k: string, v: string) => {
    const arr = form[k as keyof typeof form] as string[]
    update(k, arr.includes(v) ? arr.filter(x=>x!==v) : [...arr,v])
  }

  async function launch() {
    try {
      await fetch('/api/campaigns', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form) })
    } catch {}
    setLaunched(true)
  }

  const Tag = ({label, selected, onClick}: {label:string,selected:boolean,onClick:()=>void}) => (
    <button onClick={onClick} style={{fontSize:11,padding:'6px 14px',border:`0.5px solid ${selected?'#B8860B':'#e5e5e5'}`,background:selected?'#fdf8ee':'#fff',color:selected?'#8B5E0A':'#666',borderRadius:2,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>{label}</button>
  )

  if (launched) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',minHeight:'80vh',textAlign:'center',padding:'2rem'}}>
      <div style={{width:60,height:60,borderRadius:'50%',border:'0.5px solid #d4a843',display:'flex',alignItems:'center',justifyContent:'center',marginBottom:'1.5rem',fontSize:24}}>✓</div>
      <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:36,fontWeight:300,marginBottom:'0.75rem'}}>Campaign is Live!</h2>
      <p style={{fontSize:13,color:'#999',maxWidth:380,lineHeight:1.7,marginBottom:'2rem'}}>Your campaign has been submitted. Hinflu will now match it with eligible creators. You'll receive applications within 24–48 hours.</p>
      <div style={{display:'flex',gap:10}}>
        <Link href="/brand/campaigns" style={{padding:'10px 24px',background:'#B8860B',color:'#fff',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none'}}>View Campaigns</Link>
        <Link href="/brand/dashboard" style={{padding:'10px 20px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,color:'#333',textDecoration:'none'}}>Go to Dashboard</Link>
      </div>
    </div>
  )

  return (
    <div>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 1.5rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <div>
          <div style={{fontSize:14,fontWeight:500}}>New Campaign</div>
          <div style={{fontSize:11,color:'#999'}}>Step {step} of {STEPS.length} — {STEPS[step-1]}</div>
        </div>
        <Link href="/brand/campaigns" style={{fontSize:12,color:'#999',textDecoration:'none'}}>← Cancel</Link>
      </div>

      {/* Progress */}
      <div style={{height:3,background:'#f0f0f0'}}>
        <div style={{height:3,background:'#B8860B',width:`${(step/STEPS.length)*100}%`,transition:'width 0.3s'}}/>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'200px 1fr'}}>
        {/* Steps sidebar */}
        <div style={{background:'#fafafa',borderRight:'0.5px solid #e5e5e5',padding:'1.5rem 0',minHeight:'calc(100vh - 80px)'}}>
          {STEPS.map((s,i) => (
            <div key={s} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 1.25rem',borderLeft:step===i+1?'2px solid #B8860B':'2px solid transparent',background:step===i+1?'#fff':'transparent'}}>
              <div style={{width:22,height:22,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:500,background:step>i+1?'#B8860B':step===i+1?'#1a1a1a':'#fff',color:step>=i+1?'#fff':'#999',border:`0.5px solid ${step>i+1?'#B8860B':step===i+1?'#1a1a1a':'#e5e5e5'}`}}>
                {step>i+1?'✓':i+1}
              </div>
              <span style={{fontSize:12,color:step===i+1?'#1a1a1a':'#999',fontWeight:step===i+1?500:400}}>{s}</span>
            </div>
          ))}
        </div>

        {/* Form content */}
        <div style={{padding:'2rem',maxWidth:580}}>
          {/* STEP 1 */}
          {step===1 && <>
            <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 1 of 5</div>
            <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Campaign Basics</h2>
            {[{k:'title',lbl:'Campaign Name',ph:'e.g. Summer Glow Collection 2026'},{k:'product_name',lbl:'Product / Service',ph:'e.g. Luxury skincare — Soleil range'}].map(({k,lbl,ph}) => (
              <div key={k} style={{marginBottom:'1.25rem'}}>
                <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>{lbl}</label>
                <input value={form[k as keyof typeof form] as string} onChange={e=>update(k,e.target.value)} placeholder={ph} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
              </div>
            ))}
            <div style={{marginBottom:'1.25rem'}}>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Campaign Brief</label>
              <textarea value={form.brief} onChange={e=>update('brief',e.target.value)} placeholder="Describe what you want creators to communicate, the tone, key messages..." rows={4} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif",resize:'vertical'}}/>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1.25rem'}}>
              {[{k:'industry',lbl:'Industry',opts:['Fashion','Beauty','Technology','Food','Luxury','Travel','Finance','Fitness']},{k:'region',lbl:'Target Region',opts:['UAE','MENA','Global','UK','US','South Asia']}].map(({k,lbl,opts}) => (
                <div key={k}>
                  <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>{lbl}</label>
                  <select value={form[k as keyof typeof form] as string} onChange={e=>update(k,e.target.value)} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif",background:'#fff'}}>
                    {opts.map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </>}

          {/* STEP 2 */}
          {step===2 && <>
            <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 2 of 5</div>
            <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Campaign Objective</h2>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:'1.5rem'}}>
              {OBJECTIVES.map(o => (
                <div key={o.id} onClick={()=>update('objective',o.id)} style={{border:`0.5px solid ${form.objective===o.id?'#B8860B':'#e5e5e5'}`,background:form.objective===o.id?'#fdf8ee':'#fff',borderRadius:2,padding:'12px',cursor:'pointer'}}>
                  <div style={{fontSize:12,fontWeight:500,color:form.objective===o.id?'#8B5E0A':'#1a1a1a',marginBottom:2}}>{o.label}</div>
                  <div style={{fontSize:11,color:'#999'}}>{o.desc}</div>
                </div>
              ))}
            </div>
            <div style={{marginBottom:'1.25rem'}}>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Preferred Platforms</label>
              <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                {['instagram','tiktok','youtube','x','linkedin'].map(p => (
                  <Tag key={p} label={p.charAt(0).toUpperCase()+p.slice(1)} selected={form.platforms.includes(p)} onClick={()=>toggle('platforms',p)}/>
                ))}
              </div>
            </div>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Content Deliverables</label>
              <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                {['instagram_posts','stories','reels','tiktok_videos','youtube_review'].map(d => (
                  <Tag key={d} label={d.replace(/_/g,' ')} selected={form.deliverables.includes(d)} onClick={()=>toggle('deliverables',d)}/>
                ))}
              </div>
            </div>
          </>}

          {/* STEP 3 */}
          {step===3 && <>
            <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 3 of 5</div>
            <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Budget & Timeline</h2>
            <div style={{marginBottom:'1.5rem'}}>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Total Budget (USD)</label>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:38,fontWeight:300,color:'#B8860B',marginBottom:6}}>${form.budget.toLocaleString()}</div>
              <input type="range" min={500} max={50000} step={500} value={form.budget} onChange={e=>update('budget',parseInt(e.target.value))} style={{width:'100%'}}/>
              <div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:'#999',marginTop:4}}><span>$500</span><span>$50,000</span></div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1.25rem'}}>
              {[{k:'start_date',lbl:'Start Date'},{k:'end_date',lbl:'End Date'}].map(({k,lbl}) => (
                <div key={k}>
                  <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>{lbl}</label>
                  <input type="date" value={form[k as keyof typeof form] as string} onChange={e=>update(k,e.target.value)} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
                </div>
              ))}
            </div>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Special Requirements</label>
              <textarea value={form.requirements} onChange={e=>update('requirements',e.target.value)} placeholder="e.g. Must use brand hashtag, tag @novabrand, include discount code GLOW20..." rows={3} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif",resize:'vertical'}}/>
            </div>
          </>}

          {/* STEP 4 */}
          {step===4 && <>
            <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 4 of 5</div>
            <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Creator Criteria</h2>
            <div style={{marginBottom:'1.25rem'}}>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Influencer Tier</label>
              <div style={{display:'flex',gap:8}}>
                {['nano','micro','macro','mega'].map(t => (
                  <Tag key={t} label={t.charAt(0).toUpperCase()+t.slice(1)} selected={form.tiers.includes(t)} onClick={()=>toggle('tiers',t)}/>
                ))}
              </div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1.25rem'}}>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Min. Followers</label>
                <input type="number" value={form.min_followers} onChange={e=>update('min_followers',parseInt(e.target.value))} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:6}}>Min. Eng. Rate (%)</label>
                <input type="number" value={form.min_engagement} onChange={e=>update('min_engagement',parseFloat(e.target.value))} step={0.5} style={{width:'100%',padding:'11px 13px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',fontFamily:"'DM Sans',sans-serif"}}/>
              </div>
            </div>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:500,letterSpacing:0.5,textTransform:'uppercase',color:'#666',marginBottom:8}}>Creator Niche</label>
              <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                {['fashion','beauty','lifestyle','travel','food','fitness','tech','luxury','finance'].map(n => (
                  <Tag key={n} label={n.charAt(0).toUpperCase()+n.slice(1)} selected={form.niches.includes(n)} onClick={()=>toggle('niches',n)}/>
                ))}
              </div>
            </div>
          </>}

          {/* STEP 5 */}
          {step===5 && <>
            <div style={{fontSize:10,letterSpacing:2,textTransform:'uppercase',color:'#B8860B',marginBottom:6}}>Step 5 of 5</div>
            <h2 style={{fontFamily:"'Cormorant Garamond',serif",fontSize:28,fontWeight:300,marginBottom:'1.5rem'}}>Review & Launch</h2>
            <div style={{background:'#fafafa',border:'0.5px solid #e5e5e5',borderRadius:2,padding:'1rem',marginBottom:'1.25rem'}}>
              {[
                ['Campaign Name', form.title || '(untitled)'],
                ['Objective', form.objective.replace(/_/g,' ')],
                ['Platforms', form.platforms.join(', ')],
                ['Budget', `$${form.budget.toLocaleString()} USD`],
                ['Dates', form.start_date && form.end_date ? `${form.start_date} → ${form.end_date}` : 'Not set'],
                ['Creator Tiers', form.tiers.join(', ')],
                ['Target Region', form.region],
                ['Niches', form.niches.join(', ')],
              ].map(([k,v]) => (
                <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'0.5px solid #e5e5e5',fontSize:13}}>
                  <span style={{color:'#999'}}>{k}</span>
                  <span style={{fontWeight:500,color:k==='Budget'?'#B8860B':'#1a1a1a'}}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{fontSize:12,color:'#999',marginBottom:'1.25rem',lineHeight:1.6,padding:'1rem',background:'#fafafa',border:'0.5px solid #e5e5e5',borderRadius:2}}>
              Once launched, Hinflu will match your campaign with eligible creators who can apply. You'll review applications and select your preferred creators.
            </div>
          </>}

          {/* Nav buttons */}
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:'2rem',paddingTop:'1rem',borderTop:'0.5px solid #e5e5e5'}}>
            {step>1 ? <button onClick={()=>setStep(s=>s-1)} style={{padding:'10px 20px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,cursor:'pointer',background:'#fff',fontFamily:"'DM Sans',sans-serif",color:'#333'}}>← Back</button> : <div/>}
            {step<5 ? (
              <button onClick={()=>setStep(s=>s+1)} style={{padding:'10px 24px',background:'#1a1a1a',color:'#f5f0e8',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Continue →</button>
            ) : (
              <button onClick={launch} style={{padding:'10px 28px',background:'#B8860B',color:'#fff',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Launch Campaign</button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
