'use client'
import { useState } from 'react'

const CONVOS = [
  { id:'1', initials:'SA', name:'Sofia Amir', campaign:'Summer Glow', preview:'Content draft is ready for review...', time:'2h', unread:true, avbg:'#fdf3de', avc:'#8B5E0A', status:'Content submitted', statusBg:'#fdf3de', statusC:'#8B5E0A', statusBorder:'#d4a843', fee:'$1,800',
    messages:[
      {from:'creator',body:"Hi! I've reviewed the brief for Summer Glow. I love the concept! Do you have brand colours I should stick to, and is there a specific CTA for the caption?",time:'Yesterday, 10:14 AM'},
      {from:'brand',body:"Hey Sofia! Yes — our colours are warm gold and cream. For CTA, please include code GLOW20 for 20% off, and tag @novabrand. Feel free to use your own voice for the caption, just keep it luxurious and authentic.",time:'Yesterday, 11:02 AM'},
      {from:'creator',body:"Perfect, that's very helpful. I'll film tomorrow morning in natural light. Will send the draft within 48 hours for your approval.",time:'Yesterday, 11:18 AM'},
    ]
  },
  { id:'2', initials:'JK', name:'James Ko', campaign:'Tech Launch Q3', preview:"Sounds great, I'll get started!", time:'5h', unread:false, avbg:'#e8f0f5', avc:'#1a4a6b', status:'In progress', statusBg:'#e8f0f5', statusC:'#1a4a6b', statusBorder:'#8ab0cc', fee:'$2,400',
    messages:[
      {from:'brand',body:"Hey James, welcome to the Tech Launch campaign! I've attached the full brief in the contract. Let me know if you have questions.",time:'5h ago'},
      {from:'creator',body:"Sounds great, I'll get started on the YouTube script this week and share a draft with you before filming.",time:'4h ago'},
    ]
  },
  { id:'3', initials:'NA', name:'Nour Al-Rashid', campaign:'Ramadan Edit', preview:'Can we adjust the brief slightly?', time:'1d', unread:true, avbg:'#f0e8f5', avc:'#5a1a7a', status:'In progress', statusBg:'#e8f0f5', statusC:'#1a4a6b', statusBorder:'#8ab0cc', fee:'$900',
    messages:[
      {from:'creator',body:"Hi! I love the Ramadan Edit concept. Can we adjust the brief slightly? I'd like to incorporate my personal Ramadan routine to make content feel more authentic.",time:'1d ago'},
      {from:'brand',body:"Absolutely! Authenticity is key. Feel free to personalise as long as the product gets at least 30 seconds of screen time.",time:'22h ago'},
    ]
  },
  { id:'4', initials:'RL', name:'Rania Levi', campaign:'Fall Collection', preview:'Payment confirmed, thank you!', time:'2d', unread:false, avbg:'#e1f5ee', avc:'#085041', status:'Completed', statusBg:'#EAF3DE', statusC:'#27500A', statusBorder:'#97C459', fee:'$650',
    messages:[
      {from:'creator',body:"Payment confirmed, thank you so much! It was a pleasure working with Nova Brand. Hope we can collaborate again soon!",time:'2d ago'},
      {from:'brand',body:"Likewise Rania! Your content performed really well. We'll definitely be back for the spring campaign.",time:'2d ago'},
    ]
  },
]

export default function MessagesPage() {
  const [active, setActive] = useState(CONVOS[0])
  const [input, setInput] = useState('')
  const [msgs, setMsgs] = useState<{[key:string]: typeof CONVOS[0]['messages']}>(
    Object.fromEntries(CONVOS.map(c => [c.id, c.messages]))
  )
  const [submitted, setSubmitted] = useState(false)

  function send() {
    if (!input.trim()) return
    setMsgs(prev => ({...prev, [active.id]: [...prev[active.id], {from:'brand',body:input.trim(),time:'Just now'}]}))
    setInput('')
  }

  return (
    <div style={{display:'grid',gridTemplateColumns:'230px 1fr',height:'100vh',border:'0.5px solid #e5e5e5'}}>
      {/* Conversation list */}
      <div style={{background:'#fafafa',borderRight:'0.5px solid #e5e5e5',display:'flex',flexDirection:'column'}}>
        <div style={{padding:'1rem',borderBottom:'0.5px solid #e5e5e5',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{fontSize:13,fontWeight:500}}>Messages</div>
          <button style={{width:26,height:26,borderRadius:'50%',border:'0.5px solid #e5e5e5',background:'transparent',cursor:'pointer',fontSize:14,display:'flex',alignItems:'center',justifyContent:'center'}}>+</button>
        </div>
        {CONVOS.map(c => (
          <div key={c.id} onClick={()=>setActive(c)} style={{display:'flex',gap:10,padding:'10px 1rem',cursor:'pointer',borderBottom:'0.5px solid #e5e5e5',borderLeft:active.id===c.id?'2px solid #B8860B':'2px solid transparent',background:active.id===c.id?'#fff':'transparent',alignItems:'flex-start'}}>
            <div style={{width:34,height:34,borderRadius:'50%',background:c.avbg,color:c.avc,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Cormorant Garamond',serif",fontSize:13,fontWeight:600,flexShrink:0}}>{c.initials}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div style={{fontSize:12,fontWeight:500}}>{c.name}</div>
                <div style={{fontSize:10,color:'#999'}}>{c.time}</div>
              </div>
              <div style={{fontSize:11,color:'#999',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',maxWidth:130}}>{c.preview}</div>
            </div>
            {c.unread && <div style={{width:8,height:8,borderRadius:'50%',background:'#B8860B',flexShrink:0,marginTop:4}}/>}
          </div>
        ))}
      </div>

      {/* Chat panel */}
      <div style={{display:'flex',flexDirection:'column',background:'#fff'}}>
        {/* Chat topbar */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.875rem 1.25rem',borderBottom:'0.5px solid #e5e5e5'}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:36,height:36,borderRadius:'50%',background:active.avbg,color:active.avc,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Cormorant Garamond',serif",fontSize:14,fontWeight:600}}>{active.initials}</div>
            <div>
              <div style={{fontSize:14,fontWeight:500}}>{active.name}</div>
              <div style={{fontSize:11,color:'#999'}}>{active.campaign} campaign · Fee: {active.fee}</div>
            </div>
          </div>
          <div style={{display:'flex',gap:8}}>
            <button style={{padding:'6px 14px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:11,cursor:'pointer',background:'#fff',color:'#333',fontFamily:"'DM Sans',sans-serif"}}>View Profile</button>
            <button style={{padding:'6px 14px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:11,cursor:'pointer',background:'#fff',color:'#333',fontFamily:"'DM Sans',sans-serif"}}>Contract</button>
            <button style={{padding:'6px 14px',background:'#B8860B',color:'#fff',border:'none',borderRadius:2,fontSize:11,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Release Payment</button>
          </div>
        </div>

        {/* Campaign banner */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 1.25rem',background:'#fdf8ee',borderBottom:'0.5px solid #d4c5a0'}}>
          <div style={{fontSize:12,color:'#633806'}}>{active.campaign} · Deliverables: 2 posts + 3 stories · Fee: {active.fee}</div>
          <span style={{fontSize:10,padding:'3px 10px',background:'#fdf3de',color:'#8B5E0A',border:'0.5px solid #d4a843',borderRadius:1,letterSpacing:0.3}}>{active.status}</span>
        </div>

        {/* Messages */}
        <div style={{flex:1,padding:'1.25rem',display:'flex',flexDirection:'column',gap:12,overflowY:'auto'}}>
          {msgs[active.id].map((m,i) => (
            <div key={i} style={{maxWidth:'75%',alignSelf:m.from==='brand'?'flex-end':'flex-start'}}>
              <div style={{padding:'10px 14px',borderRadius:2,fontSize:13,lineHeight:1.55,background:m.from==='brand'?'#1a1a1a':'#f5f5f5',color:m.from==='brand'?'#f5f0e8':'#1a1a1a',border:m.from==='creator'?'0.5px solid #e5e5e5':'none'}}>{m.body}</div>
              <div style={{fontSize:10,color:'#999',marginTop:4,textAlign:m.from==='brand'?'right':'left'}}>{m.time}</div>
            </div>
          ))}

          {/* Content submission card for Sofia */}
          {active.id==='1' && (
            <div style={{maxWidth:'75%',alignSelf:'flex-start',background:'#fafafa',border:'0.5px solid #e5e5e5',borderRadius:2,padding:'10px 14px'}}>
              <div style={{fontSize:10,letterSpacing:1,textTransform:'uppercase',color:'#999',marginBottom:6}}>Content Submission</div>
              <div style={{fontSize:13,fontWeight:500,marginBottom:4}}>Summer Glow — Draft post + stories (3 files)</div>
              <div style={{fontSize:11,color:'#999',marginBottom:10}}>Submitted 2 hours ago · Instagram post + 3 story frames</div>
              {!submitted ? (
                <div style={{display:'flex',gap:6}}>
                  <button onClick={()=>setSubmitted(true)} style={{padding:'5px 14px',background:'#EAF3DE',color:'#27500A',border:'0.5px solid #97C459',borderRadius:2,fontSize:11,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Approve Content</button>
                  <button style={{padding:'5px 14px',background:'transparent',color:'#666',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:11,cursor:'pointer',fontFamily:"'DM Sans',sans-serif"}}>Request Revisions</button>
                </div>
              ) : (
                <div style={{fontSize:11,color:'#27500A',fontWeight:500}}>✓ Content Approved</div>
              )}
            </div>
          )}
        </div>

        {/* Input */}
        <div style={{padding:'1rem 1.25rem',borderTop:'0.5px solid #e5e5e5',display:'flex',gap:8,alignItems:'flex-end'}}>
          <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}} placeholder={`Write a message to ${active.name}...`} rows={2} style={{flex:1,padding:'10px 12px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:13,outline:'none',resize:'none',fontFamily:"'DM Sans',sans-serif"}}/>
          <button onClick={send} style={{padding:'10px 18px',background:'#1a1a1a',color:'#f5f0e8',border:'none',borderRadius:2,fontSize:12,fontWeight:500,cursor:'pointer',fontFamily:"'DM Sans',sans-serif",whiteSpace:'nowrap'}}>Send</button>
        </div>
      </div>
    </div>
  )
}
