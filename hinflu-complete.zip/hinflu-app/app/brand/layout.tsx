import BrandSidebar from '@/components/layout/BrandSidebar'

export default function BrandLayout({ children }: { children: React.ReactNode }) {
  return (
    <div style={{display:'flex',minHeight:'100vh',background:'#fff'}}>
      <BrandSidebar />
      <main style={{marginLeft:210,flex:1,minHeight:'100vh',background:'#fff'}}>
        {children}
      </main>
    </div>
  )
}
