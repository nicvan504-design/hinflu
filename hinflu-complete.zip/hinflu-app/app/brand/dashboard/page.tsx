'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'

const metrics = [
  { label:'Active Campaigns', value:'3', delta:'+1 this month', color:'#3B6D11' },
  { label:'Total Reach', value:'4.2M', delta:'+18% vs last month', color:'#3B6D11' },
  { label:'Avg. Eng. Rate', value:'9.4%', delta:'+2.1% vs last', color:'#3B6D11' },
  { label:'Total Spend', value:'$12.6K', delta:'$3.2K remaining', color:'#BA7517' },
]

const campaigns = [
  { name:'Summer Glow', niche:'Beauty · Lifestyle', status:'Live', statusColor:'#27500A', statusBg:'#EAF3DE', statusBorder:'#97C459', reach:'1.8M', budget:'$4,500' },
  { name:'Tech Launch Q3', niche:'Technology', status:'In Review', statusColor:'#633806', statusBg:'#FAEEDA', statusBorder:'#EF9F27', reach:'920K', budget:'$6,200' },
  { name:'Ramadan Edit', niche:'Fashion · Luxury', status:'Live', statusColor:'#27500A', statusBg:'#EAF3DE', statusBorder:'#97C459', reach:'1.5M', budget:'$1,900' },
]

const creators = [
  { initials:'SA', name:'Sofia Amir', niche:'Fashion · Lifestyle', tier:'Mega', tierbg:'#f0e8f5', tierc:'#5a1a7a', followers:'2.4M', eng:'8.2%', avbg:'#fdf3de', avc:'#8B5E0A' },
  { initials:'JK', name:'James Ko', niche:'Tech · Finance', tier:'Macro', tierbg:'#e8f0f5', tierc:'#1a4a6b', followers:'180K', eng:'12.4%', avbg:'#e8f0f5', avc:'#1a4a6b' },
  { initials:'NA', name:'Nour Al-Rashid', niche:'Beauty · Wellness', tier:'Micro', tierbg:'#fdf3de', tierc:'#8B5E0A', followers:'42K', eng:'19.1%', avbg:'#f0e8f5', avc:'#5a1a7a' },
]

const activity = [
  { text:'Sofia Amir submitted content for Summer Glow — pending your approval', time:'2 hours ago', dotColor:'#3B6D11' },
  { text:'James Ko accepted your collaboration invite for Tech Launch Q3', time:'5 hours ago', dotColor:'#378ADD' },
  { text:'Payment of $1,200 released to Nour Al-Rashid for Ramadan Edit', time:'Yesterday', dotColor:'#B8860B' },
  { text:'Fall Collection campaign ended — final report is ready', time:'2 days ago', dotColor:'#ccc' },
]

export default function BrandDashboard() {
  return (
    <div>
      {/* Topbar */}
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'1rem 1.5rem',borderBottom:'0.5px solid #e5e5e5'}}>
        <div>
          <div style={{fontSize:15,fontWeight:500}}>Good morning, Nova Brand</div>
          <div style={{fontSize:12,color:'#999',marginTop:2}}>Here's what's happening with your campaigns today</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <Link href="/discover" style={{padding:'8px 16px',border:'0.5px solid #e5e5e5',borderRadius:2,fontSize:12,color:'#333',textDecoration:'none',background:'#fff'}}>Browse Creators</Link>
          <Link href="/brand/campaigns/new" style={{padding:'8px 18px',background:'#B8860B',color:'#fff',borderRadius:2,fontSize:12,fontWeight:500,textDecoration:'none'}}>+ New Campaign</Link>
        </div>
      </div>

      <div style={{padding:'1.25rem 1.5rem'}}>
        {/* Metrics */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:'1.25rem'}}>
          {metrics.map(m => (
            <div key={m.label} style={{background:'#fafafa',borderRadius:8,padding:'0.875rem',border:'0.5px solid #f0f0f0'}}>
              <div style={{fontSize:10,color:'#999',letterSpacing:0.5,textTransform:'uppercase',marginBottom:5}}>{m.label}</div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,fontWeight:300,lineHeight:1}}>{m.value}</div>
              <div style={{fontSize:10,marginTop:3,color:m.color}}>{m.delta}</div>
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'1rem',marginBottom:'1rem'}}>
          {/* Campaigns */}
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
              <div style={{fontSize:13,fontWeight:500}}>Active Campaigns</div>
              <Link href="/brand/campaigns" style={{fontSize:11,color:'#B8860B',textDecoration:'none'}}>View all</Link>
            </div>
            {campaigns.map(c => (
              <div key={c.name} style={{display:'grid',gridTemplateColumns:'1fr 90px 60px 70px',alignItems:'center',gap:8,padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5',fontSize:12}}>
                <div><div style={{fontWeight:500}}>{c.name}</div><div style={{fontSize:11,color:'#999'}}>{c.niche}</div></div>
                <div><span style={{fontSize:10,padding:'3px 8px',borderRadius:1,background:c.statusBg,color:c.statusColor,border:`0.5px solid ${c.statusBorder}`}}>{c.status}</span></div>
                <div style={{fontSize:11,color:'#999'}}>{c.reach}</div>
                <div style={{fontWeight:500,textAlign:'right'}}>{c.budget}</div>
              </div>
            ))}
          </div>

          {/* Shortlisted */}
          <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
              <div style={{fontSize:13,fontWeight:500}}>Shortlisted Creators</div>
              <Link href="/discover" style={{fontSize:11,color:'#B8860B',textDecoration:'none'}}>Browse all</Link>
            </div>
            {creators.map(c => (
              <div key={c.name} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5',cursor:'pointer'}}>
                <div style={{width:34,height:34,borderRadius:'50%',background:c.avbg,color:c.avc,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Cormorant Garamond',serif",fontSize:13,fontWeight:600,flexShrink:0}}>{c.initials}</div>
                <div style={{flex:1}}>
                  <div style={{display:'flex',alignItems:'center',gap:6}}>
                    <span style={{fontSize:12,fontWeight:500}}>{c.name}</span>
                    <span style={{fontSize:10,padding:'2px 7px',background:c.tierbg,color:c.tierc,border:`0.5px solid ${c.tierc}44`,borderRadius:1}}>{c.tier}</span>
                  </div>
                  <div style={{fontSize:11,color:'#999'}}>{c.niche}</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div style={{fontSize:12,fontWeight:500}}>{c.followers}</div>
                  <div style={{fontSize:10,color:'#3B6D11'}}>{c.eng} eng.</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Activity */}
        <div style={{border:'0.5px solid #e5e5e5',borderRadius:8,overflow:'hidden'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0.75rem 1rem',borderBottom:'0.5px solid #e5e5e5'}}>
            <div style={{fontSize:13,fontWeight:500}}>Recent Activity</div>
          </div>
          {activity.map((a,i) => (
            <div key={i} style={{display:'flex',alignItems:'flex-start',gap:10,padding:'10px 1rem',borderBottom:'0.5px solid #f5f5f5'}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:a.dotColor,marginTop:4,flexShrink:0}}/>
              <div><div style={{fontSize:12,lineHeight:1.5}}>{a.text}</div><div style={{fontSize:10,color:'#999',marginTop:2}}>{a.time}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
