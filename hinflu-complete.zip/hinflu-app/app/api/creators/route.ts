import { NextRequest, NextResponse } from 'next/server'

const creators = [
  { id:'1', display_name:'Sofia Amir', bio:'Luxury fashion creator', country:'UAE', tier:'mega', niche:['fashion','lifestyle'], total_followers:2400000, avg_engagement:8.2, is_verified:true },
  { id:'2', display_name:'James Ko', bio:'Tech & finance creator', country:'UK', tier:'macro', niche:['tech','finance'], total_followers:180000, avg_engagement:12.4, is_verified:true },
  { id:'3', display_name:'Nour Al-Rashid', bio:'Beauty & wellness', country:'KSA', tier:'micro', niche:['beauty','wellness'], total_followers:42000, avg_engagement:19.1, is_verified:true },
]

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const search = searchParams.get('search') || ''
  const tier = searchParams.get('tier') || ''
  let result = creators
  if (search) result = result.filter(c => c.display_name.toLowerCase().includes(search.toLowerCase()))
  if (tier) result = result.filter(c => c.tier === tier)
  return NextResponse.json({ total: result.length, creators: result })
}
