import { NextRequest, NextResponse } from 'next/server'

const campaigns = [
  { id:'1', title:'Summer Glow Collection', brand:{ name:'Nova Brand' }, objective:'brand_awareness', niche:['fashion','beauty'], platforms:['instagram','tiktok'], tiers_allowed:['micro','macro'], budget_per_creator:1800, status:'active' },
  { id:'2', title:'Tech Launch Q3', brand:{ name:'TechCorp' }, objective:'product_sales', niche:['tech'], platforms:['youtube'], tiers_allowed:['macro'], budget_per_creator:2400, status:'active' },
]

export async function GET(req: NextRequest) {
  // In production: query Supabase campaigns table with filters
  return NextResponse.json({ total: campaigns.length, campaigns })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const newCampaign = { id: Date.now().toString(), ...body, status: 'draft', created_at: new Date().toISOString() }
    // In production: insert into Supabase
    return NextResponse.json({ campaign: newCampaign }, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Failed to create campaign' }, { status: 500 })
  }
}
