import { NextResponse } from 'next/server'
export async function GET() {
  // In production: get from Supabase based on auth session
  return NextResponse.json({ id:'demo', brand_name:'Nova Brand', plan:'pro', industry:'Fashion', hq_country:'UAE' })
}
