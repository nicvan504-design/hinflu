import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json()
    if (!email || !password) return NextResponse.json({ error: 'Missing credentials' }, { status: 400 })
    // In production: call Supabase auth.signInWithPassword here
    const role = email.includes('creator') ? 'creator' : 'brand'
    return NextResponse.json({ user: { id: 'demo-id', email, role }, role, token: 'demo-token' })
  } catch {
    return NextResponse.json({ error: 'Login failed' }, { status: 500 })
  }
}
