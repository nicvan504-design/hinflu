import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { email, password, full_name, role } = await req.json()
    if (!email || !password || !full_name || !role) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }
    // In production: call Supabase auth.signUp here
    // const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name, role } } })
    return NextResponse.json({ user: { id: 'demo-id', email, role, full_name }, role }, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Registration failed' }, { status: 500 })
  }
}
