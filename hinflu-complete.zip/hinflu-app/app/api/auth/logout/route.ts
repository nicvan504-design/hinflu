import { NextResponse } from 'next/server'
export async function POST() {
  // In production: call supabase.auth.signOut()
  return NextResponse.json({ message: 'Logged out successfully' })
}
