/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        serif: ['Cormorant Garamond', 'serif'],
      },
      colors: {
        gold: { DEFAULT: '#B8860B', light: '#d4a843', pale: '#fdf8ee', dark: '#8B5E0A' },
      },
    },
  },
  plugins: [],
}
